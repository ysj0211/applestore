$(function(){
  /* pt1의 hover 효과 */
  $("#pt1").hover(function(){
    $("#pt1 img").css("border-color","#f58a78");
    $("#t1").css({color: "#f58a78",textDecoration:"underline", fontWeight : "bold" });
  }, function(){
    $("#pt1 img").css("border-color","#ccc");
    $("#t1").css({color:"#333", textDecoration :"none", fontWeight: "normal"});
  });
  /* pt2의 hover 효과 */
  $("#pt2").hover(function(){
    $("#pt2 img").css("border-color","#f58a78");
    $("#t2").css({color: "#f58a78",textDecoration:"underline", fontWeight : "bold" });
  }, function(){
    $("#pt2 img").css("border-color","#ccc");
    $("#t2").css({color:"#333", textDecoration :"none", fontWeight: "normal"});
  });
  /* pt3의 hover 효과 */
  $("#pt3").hover(function(){
    $("#pt3 img").css("border-color","#f58a78");
    $("#t3").css({color: "#f58a78",textDecoration:"underline", fontWeight : "bold" });
  }, function(){
    $("#pt3 img").css("border-color","#ccc");
    $("#t3").css({color:"#333", textDecoration :"none", fontWeight: "normal"});
  });


  /* t1의 hover 효과 */
  $("#t1").hover(function(){
    $("#pt1 img").css("border-color","#f58a78");
    $("#t1").css({color: "#f58a78",textDecoration:"underline", fontWeight : "bold" });
  }, function(){
    $("#pt1 img").css("border-color","#ccc");
    $("#t1").css({color:"#333", textDecoration :"none", fontWeight: "normal"});
  });
  /* t2의 hover 효과 */
  $("#t2").hover(function(){
    $("#pt2 img").css("border-color","#f58a78");
    $("#t2").css({color: "#f58a78",textDecoration:"underline", fontWeight : "bold" });
  }, function(){
    $("#pt2 img").css("border-color","#ccc");
    $("#t2").css({color:"#333", textDecoration :"none", fontWeight: "normal"});
  });
   /* t3의 hover 효과 */
  $("#t3").hover(function(){
    $("#pt3 img").css("border-color","#f58a78");
    $("#t3").css({color: "#f58a78",textDecoration:"underline", fontWeight : "bold" });
  }, function(){
    $("#pt3 img").css("border-color","#ccc");
    $("#t3").css({color:"#333", textDecoration :"none", fontWeight: "normal"});
  });












});